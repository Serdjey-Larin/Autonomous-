import 'package:flutter_sms/flutter_sms.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'protocol.dart';

class VehicleConfig {
  VehicleConfig({
    this.deviceNumber = '',
    this.ownerNumber = '',
    this.vehicleName = 'Мой автомобиль',
    this.durationMinutes = 30,
    this.ussdCode = '',
  });

  String deviceNumber;
  String ownerNumber;
  String vehicleName;
  int durationMinutes;
  String ussdCode;
}

class DeviceService {
  final SharedPreferencesAsync _prefs = SharedPreferencesAsync();

  Future<VehicleConfig> load() async {
    final minutes = await _prefs.getInt('durationMinutes') ?? 30;
    return VehicleConfig(
      deviceNumber: await _prefs.getString('deviceNumber') ?? '',
      ownerNumber: await _prefs.getString('ownerNumber') ?? '',
      vehicleName: await _prefs.getString('vehicleName') ?? 'Мой автомобиль',
      durationMinutes: GsmProtocol.validDuration(minutes) ? minutes : 30,
      ussdCode: await _prefs.getString('ussdCode') ?? '',
    );
  }

  Future<void> save(VehicleConfig config) async {
    await _prefs.setString('deviceNumber', config.deviceNumber);
    await _prefs.setString('ownerNumber', config.ownerNumber);
    await _prefs.setString('vehicleName', config.vehicleName);
    await _prefs.setInt('durationMinutes', config.durationMinutes);
    await _prefs.setString('ussdCode', config.ussdCode);
  }

  /// Нативный редактор SMS на Android/iOS. ПОЛЬЗОВАТЕЛЬ сам нажимает Отправить.
  /// Возвращаемое значение плагина не подтверждает ни доставку, ни запуск отопителя.
  Future<bool> composeSms(String deviceNumber, String text) async {
    final normalized = GsmProtocol.normalizePhone(deviceNumber);
    if (!GsmProtocol.validPhone(normalized)) {
      throw const FormatException('Сначала укажи номер SIM-карты модуля (+7…)');
    }
    try {
      final result = await sendSMS(message: text, recipients: <String>[normalized]);
      final normalizedResult = result.toLowerCase();
      // На разных платформах результат называется по-разному. Отмена НЕ
      // должна повторно открывать окно SMS и не должна считаться отправкой.
      if (normalizedResult.contains('cancel')) return false;
      return true;
    } catch (e) {
      final reason = e.toString().toLowerCase();
      if (reason.contains('cancel')) return false;
      throw StateError('Не удалось открыть редактор SMS: $e');
    }
  }

  /// Звонок — только ПЕРЕКЛЮЧЕНИЕ, а не однозначный запуск/остановка.
  Future<void> call(String deviceNumber) async {
    final normalized = GsmProtocol.normalizePhone(deviceNumber);
    if (!GsmProtocol.validPhone(normalized)) {
      throw const FormatException('Сначала укажи номер SIM-карты модуля (+7…)');
    }
    if (!await launchUrl(Uri(scheme: 'tel', path: normalized))) {
      throw StateError('Не удалось открыть телефон.');
    }
  }
}
