#!/usr/bin/env bash
set -euo pipefail
for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  dest="android/app/src/main/res/mipmap-${density}"
  mkdir -p "$dest"
  cp "android_icons/mipmap-${density}/ic_launcher.png" "$dest/ic_launcher.png"
done
manifest="android/app/src/main/AndroidManifest.xml"
if [ -f "$manifest" ]; then
  sed -i 's/android:label="larin_cold_gsm_control"/android:label="LARIN COLD GSM Control"/g' "$manifest"
fi
